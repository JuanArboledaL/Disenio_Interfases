﻿namespace ProyectoAuto
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.nombreMarca = new System.Windows.Forms.Label();
            this.modeloCoches = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.imagenesDeLosModelos = new System.Windows.Forms.PictureBox();
            this.Adicionales = new System.Windows.Forms.ListBox();
            this.Agregar = new System.Windows.Forms.Button();
            this.seleccionados = new System.Windows.Forms.ListBox();
            this.quitar = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.FechaEntrega = new System.Windows.Forms.Label();
            this.numPuertas = new System.Windows.Forms.Label();
            this.cantPuertas = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagenesDeLosModelos)).BeginInit();
            this.SuspendLayout();
            // 
            // nombreMarca
            // 
            this.nombreMarca.AutoSize = true;
            this.nombreMarca.BackColor = System.Drawing.Color.Transparent;
            this.nombreMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 57.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombreMarca.Location = new System.Drawing.Point(215, 53);
            this.nombreMarca.Name = "nombreMarca";
            this.nombreMarca.Size = new System.Drawing.Size(359, 87);
            this.nombreMarca.TabIndex = 0;
            this.nombreMarca.Text = "TOYOTA";
            this.nombreMarca.Click += new System.EventHandler(this.label1_Click);
            // 
            // modeloCoches
            // 
            this.modeloCoches.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.modeloCoches.DisplayMember = "rfefr";
            this.modeloCoches.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.modeloCoches.FormattingEnabled = true;
            this.modeloCoches.Items.AddRange(new object[] {
            "Land Cruiser Prado",
            "Yaris",
            "Corolla",
            "C-HR",
            "4RUNNER",
            "GT86"});
            this.modeloCoches.Location = new System.Drawing.Point(356, 179);
            this.modeloCoches.Name = "modeloCoches";
            this.modeloCoches.Size = new System.Drawing.Size(218, 21);
            this.modeloCoches.TabIndex = 1;
            this.modeloCoches.Tag = "";
            this.modeloCoches.SelectedIndexChanged += new System.EventHandler(this.modeloCoches_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ImageLocation = "C:\\Users\\Juanito\\source\\repos\\ProyectoAuto\\toyota.png";
            this.pictureBox1.Location = new System.Drawing.Point(561, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // imagenesDeLosModelos
            // 
            this.imagenesDeLosModelos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.imagenesDeLosModelos.Location = new System.Drawing.Point(230, 397);
            this.imagenesDeLosModelos.Name = "imagenesDeLosModelos";
            this.imagenesDeLosModelos.Size = new System.Drawing.Size(434, 225);
            this.imagenesDeLosModelos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imagenesDeLosModelos.TabIndex = 2;
            this.imagenesDeLosModelos.TabStop = false;
            this.imagenesDeLosModelos.Click += new System.EventHandler(this.imagenesDeLosModelos_Click);
            // 
            // Adicionales
            // 
            this.Adicionales.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Adicionales.FormattingEnabled = true;
            this.Adicionales.Location = new System.Drawing.Point(230, 226);
            this.Adicionales.Name = "Adicionales";
            this.Adicionales.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.Adicionales.Size = new System.Drawing.Size(151, 95);
            this.Adicionales.TabIndex = 4;
            this.Adicionales.SelectedIndexChanged += new System.EventHandler(this.Adicionales_SelectedIndexChanged);
            // 
            // Agregar
            // 
            this.Agregar.Location = new System.Drawing.Point(408, 226);
            this.Agregar.Name = "Agregar";
            this.Agregar.Size = new System.Drawing.Size(75, 23);
            this.Agregar.TabIndex = 5;
            this.Agregar.Text = "Agregar";
            this.Agregar.UseVisualStyleBackColor = true;
            this.Agregar.Click += new System.EventHandler(this.Agregar_Click);
            // 
            // seleccionados
            // 
            this.seleccionados.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seleccionados.FormattingEnabled = true;
            this.seleccionados.Location = new System.Drawing.Point(512, 226);
            this.seleccionados.Name = "seleccionados";
            this.seleccionados.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.seleccionados.Size = new System.Drawing.Size(152, 95);
            this.seleccionados.TabIndex = 6;
            this.seleccionados.SelectedIndexChanged += new System.EventHandler(this.seleccionados_SelectedIndexChanged);
            // 
            // quitar
            // 
            this.quitar.Location = new System.Drawing.Point(408, 298);
            this.quitar.Name = "quitar";
            this.quitar.Size = new System.Drawing.Size(75, 23);
            this.quitar.TabIndex = 7;
            this.quitar.Text = "Quitar";
            this.quitar.UseVisualStyleBackColor = true;
            this.quitar.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dateTimePicker1.Location = new System.Drawing.Point(230, 689);
            this.dateTimePicker1.MinDate = new System.DateTime(2024, 10, 2, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 8;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // FechaEntrega
            // 
            this.FechaEntrega.AutoSize = true;
            this.FechaEntrega.ForeColor = System.Drawing.Color.Black;
            this.FechaEntrega.Location = new System.Drawing.Point(227, 657);
            this.FechaEntrega.Name = "FechaEntrega";
            this.FechaEntrega.Size = new System.Drawing.Size(169, 13);
            this.FechaEntrega.TabIndex = 9;
            this.FechaEntrega.Text = "Fecha en la que desea su entrega";
            this.FechaEntrega.Click += new System.EventHandler(this.FechaEntrega_Click);
            // 
            // numPuertas
            // 
            this.numPuertas.AutoSize = true;
            this.numPuertas.ForeColor = System.Drawing.Color.Black;
            this.numPuertas.Location = new System.Drawing.Point(227, 355);
            this.numPuertas.Name = "numPuertas";
            this.numPuertas.Size = new System.Drawing.Size(102, 13);
            this.numPuertas.TabIndex = 10;
            this.numPuertas.Text = "Cantidad de puertas";
            this.numPuertas.Click += new System.EventHandler(this.numPuertas_Click);
            // 
            // cantPuertas
            // 
            this.cantPuertas.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cantPuertas.FormattingEnabled = true;
            this.cantPuertas.Items.AddRange(new object[] {
            "3",
            "5"});
            this.cantPuertas.Location = new System.Drawing.Point(356, 355);
            this.cantPuertas.Name = "cantPuertas";
            this.cantPuertas.Size = new System.Drawing.Size(40, 21);
            this.cantPuertas.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(877, 882);
            this.Controls.Add(this.cantPuertas);
            this.Controls.Add(this.numPuertas);
            this.Controls.Add(this.FechaEntrega);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.quitar);
            this.Controls.Add(this.seleccionados);
            this.Controls.Add(this.Agregar);
            this.Controls.Add(this.Adicionales);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.imagenesDeLosModelos);
            this.Controls.Add(this.modeloCoches);
            this.Controls.Add(this.nombreMarca);
            this.ForeColor = System.Drawing.Color.Red;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagenesDeLosModelos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nombreMarca;
        private System.Windows.Forms.ComboBox modeloCoches;
        private System.Windows.Forms.PictureBox imagenesDeLosModelos;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox Adicionales;
        private System.Windows.Forms.Button Agregar;
        private System.Windows.Forms.ListBox seleccionados;
        private System.Windows.Forms.Button quitar;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label FechaEntrega;
        private System.Windows.Forms.Label numPuertas;
        private System.Windows.Forms.ComboBox cantPuertas;
    }
}

